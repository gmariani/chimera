Chimera sample ZIP.
